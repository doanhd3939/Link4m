window.alert = function (message) {
    console.log("Blocked alert: " + message);
  };
  